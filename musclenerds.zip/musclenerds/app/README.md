This is our README file!


# MuscleNerds

PUSHING AND PULLING LIKE WATERBENDERS

Test Push
<<<<<<< Updated upstream



Access Granted!!!


//Tim

//Myles

This is Josh trying stuff
What up!!
=======
hello

>>>>>>> Stashed changes


Push testing -Kyle
///////////
//0/////0//
///////////
//------///
///////////
 